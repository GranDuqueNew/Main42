#!/bin/bash
git ls-files -o -i --exclude-standar
